# Changelog

All notable changes to MoonFansPro are documented here.

This project adheres to [Semantic Versioning](https://semver.org/) and [Conventional Commits](https://www.conventionalcommits.org/).

---

## [Unreleased]

### Added
- Nothing yet — be the first to contribute!

---

## [1.0.0] — 2024-01-15

### Added
- Initial platform launch
- Creator profiles with subscription tiers (free and paid)
- Fan subscription system with Stripe Billing
- Post types: photo, video, text, audio
- Pay-per-view (PPV) post locking with Stripe Payment Intents
- Direct messaging (DM) between fans and creators
- PPV message unlocking
- Tipping on posts, messages, and creator profiles
- Digital shop — product listings, orders, Stripe Checkout
- 24-hour stories (ephemeral content for subscribers)
- Bookmark and like system
- Creator dashboard with earnings overview and analytics
- Stripe Connect (Express) for creator payout onboarding
- Admin panel — user management, payout approvals, content reports
- Two-factor authentication (2FA) via email OTP
- Multi-language support: English, Español, Persian (RTL)
- Progressive Web App (PWA) — installable, offline-capable
- Earnings simulator on the homepage
- Referral system for creator recruitment
- GDPR-compliant cookie consent banner
- Static pages CMS — Terms, Privacy, About, How It Works, Cookies
- Blog system with admin-managed posts
- Creator category browsing (Animation, Art, Design, Developer, etc.)
- GitHub Actions CI/CD pipeline (test → lint → deploy)

### Security
- Stripe webhook signature verification
- Private S3 media with signed temporary URLs
- PSR-12 code standards enforced via Laravel Pint
- CSRF protection on all forms
- Admin and creator middleware guards

---

## Format Reference

```
## [version] — YYYY-MM-DD

### Added       — new features
### Changed     — changes to existing functionality
### Deprecated  — soon-to-be removed features
### Removed     — removed features
### Fixed       — bug fixes
### Security    — vulnerability fixes
```
