# Contributing to MoonFansPro

Thank you for your interest in contributing! This document outlines the process for contributing to this project.

## Table of Contents
- [Code of Conduct](#code-of-conduct)
- [Getting Started](#getting-started)
- [Development Workflow](#development-workflow)
- [Coding Standards](#coding-standards)
- [Commit Convention](#commit-convention)
- [Pull Request Process](#pull-request-process)
- [Testing](#testing)

---

## Code of Conduct

By participating in this project, you agree to uphold a respectful and inclusive environment. Harassment, discrimination, or abusive behaviour of any kind will not be tolerated.

---

## Getting Started

1. **Fork** the repository on GitHub
2. **Clone** your fork locally:
   ```bash
   git clone https://github.com/your-username/moonfanspro.git
   cd moonfanspro
   ```
3. Add the upstream remote:
   ```bash
   git remote add upstream https://github.com/original-owner/moonfanspro.git
   ```
4. Follow the [Installation](README.md#installation) steps in the README.

---

## Development Workflow

Always branch off `develop`, not `main`:

```bash
git checkout develop
git pull upstream develop
git checkout -b feature/your-feature-name
```

Branch naming conventions:

| Type        | Prefix         | Example                          |
|-------------|----------------|----------------------------------|
| Feature     | `feature/`     | `feature/ppv-message-unlock`     |
| Bug fix     | `fix/`         | `fix/stripe-webhook-signature`   |
| Refactor    | `refactor/`    | `refactor/media-service-uploads` |
| Hotfix      | `hotfix/`      | `hotfix/subscription-expiry`     |
| Docs        | `docs/`        | `docs/update-installation-guide` |
| Tests       | `test/`        | `test/creator-earnings-service`  |

---

## Coding Standards

This project follows **PSR-12** for PHP and uses **Laravel Pint** for automated formatting.

Before committing, run:

```bash
./vendor/bin/pint
```

### PHP Guidelines
- Use type hints and return types on all methods
- Prefer named arguments for clarity on long function calls
- Keep controllers thin — move business logic to `Services/`
- Use Eloquent relationships; avoid raw SQL queries unless necessary
- All database access must go through models and migrations, never `DB::statement()` for schema changes

### Blade / Frontend Guidelines
- Use Blade components (`<x-component />`) for repeated UI elements
- Keep JavaScript in `resources/js/` — no inline `<script>` blocks in views
- Use Bootstrap 5 utility classes; avoid custom CSS unless absolutely necessary
- All forms must include `@csrf`; all delete actions must use `@method('DELETE')`

### Security Guidelines
- Never expose Stripe secret keys, AWS credentials, or any secret in code
- Always validate and sanitise file uploads using `MediaService`
- All monetary amounts must be stored in cents (integer) in Stripe, and as `DECIMAL(8,2)` in the database
- Webhook handlers must verify the Stripe signature before processing

---

## Commit Convention

We use [Conventional Commits](https://www.conventionalcommits.org/):

```
<type>(<scope>): <short summary>

[optional body]

[optional footer]
```

Types:

| Type       | When to use                                  |
|------------|----------------------------------------------|
| `feat`     | New feature                                  |
| `fix`      | Bug fix                                      |
| `docs`     | Documentation changes only                   |
| `style`    | Formatting, missing semicolons — no logic    |
| `refactor` | Code change that neither fixes nor adds      |
| `test`     | Adding or correcting tests                   |
| `chore`    | Build process, dependency updates            |
| `perf`     | Performance improvement                      |

Examples:
```
feat(subscriptions): add trial period support for new creators
fix(webhook): handle missing metadata on payment_intent events
docs(readme): update S3 CORS configuration example
chore(deps): upgrade stripe-php to ^11.0
```

---

## Pull Request Process

1. Ensure all tests pass: `php artisan test`
2. Ensure code style passes: `./vendor/bin/pint --test`
3. Update the `CHANGELOG.md` with a summary of your changes under `[Unreleased]`
4. Open a Pull Request against the `develop` branch
5. Fill in the PR template completely
6. Request a review from at least one maintainer
7. PRs are squash-merged to keep a clean history

### PR Checklist
- [ ] Tests written or updated
- [ ] `CHANGELOG.md` updated
- [ ] No secrets or credentials committed
- [ ] Migration included for any schema changes
- [ ] Blade views follow existing patterns

---

## Testing

Run the full test suite:

```bash
php artisan test
```

Run a specific test file:

```bash
php artisan test tests/Feature/SubscriptionTest.php
```

Run tests in parallel:

```bash
php artisan test --parallel
```

Generate coverage report:

```bash
php artisan test --coverage --min=80
```

Test files live in:
- `tests/Feature/` — HTTP/integration tests (controllers, routes, webhooks)
- `tests/Unit/` — Pure unit tests (services, models, helpers)

When writing tests for payment flows, use Stripe's test card numbers and always mock `StripeService` in unit tests to avoid hitting the live API.
