# Security Policy

## Supported Versions

| Version | Supported          |
|---------|--------------------|
| 1.x     | ✅ Actively supported |
| < 1.0   | ❌ No longer supported |

## Reporting a Vulnerability

**Please do not report security vulnerabilities through public GitHub issues.**

If you discover a security vulnerability, please send an email to:

📧 **security@moonfanspro.com**

Include:
- A clear description of the vulnerability
- Steps to reproduce
- Potential impact
- Any suggested fixes (optional)

You can expect:
- **Acknowledgement** within 48 hours
- **Status update** within 5 business days
- **Full resolution** within 30 days for critical issues

We follow responsible disclosure. Once a fix is released, we will publicly acknowledge your contribution (unless you prefer to remain anonymous).

## Security Measures in Place

### Payment Security
- All Stripe webhook payloads are verified using signature validation (`Stripe-Signature` header)
- No raw card data is ever stored — all payment handling is delegated to Stripe
- Creator payout transfers use Stripe Connect with Express accounts

### Media Security
- All user-uploaded media is stored on **private** AWS S3 buckets
- Media URLs are signed temporary URLs (expiring in 30–60 minutes) — they cannot be shared or hotlinked
- File type validation is enforced server-side via MIME type checking, not just file extension

### Application Security
- CSRF tokens on every form
- SQL injection protection via Eloquent ORM and parameterised queries
- XSS protection via Blade's automatic output escaping (`{{ }}`)
- Rate limiting applied to login, 2FA verification, and contact form endpoints
- Passwords hashed with bcrypt (Laravel default)
- Two-factor authentication (email OTP) available for all accounts

### Infrastructure
- Environment secrets stored in `.env` (never committed — excluded via `.gitignore`)
- Production deployments use SSH key authentication
- Database credentials rotated regularly
- HTTPS enforced via Nginx with TLS 1.2+

## Known Limitations

- The platform does not currently support end-to-end encrypted messaging. Direct messages are stored in the database and accessible to administrators.
- Age verification is the responsibility of the platform operator. This codebase does not include automated age-gate mechanisms.
